#define _POSIX_V6_LP64_OFF64  1
#define _POSIX_V7_LP64_OFF64  1
#include <bits/deprecations.h>
