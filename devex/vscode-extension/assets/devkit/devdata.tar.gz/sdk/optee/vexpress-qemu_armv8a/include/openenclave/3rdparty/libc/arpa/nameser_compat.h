#include <arpa/nameser.h>

#include <bits/deprecations.h>
