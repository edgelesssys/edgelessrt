#include <linux/soundcard.h>
#include <bits/deprecations.h>
