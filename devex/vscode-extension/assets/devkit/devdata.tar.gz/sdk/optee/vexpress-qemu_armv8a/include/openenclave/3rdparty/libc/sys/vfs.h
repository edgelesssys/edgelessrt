#include <sys/statfs.h>
#include <bits/deprecations.h>
