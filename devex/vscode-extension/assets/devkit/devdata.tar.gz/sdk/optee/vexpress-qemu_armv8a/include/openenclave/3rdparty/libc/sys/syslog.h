#include <syslog.h>
#include <bits/deprecations.h>
