#include <bits/kd.h>
#include <bits/deprecations.h>
