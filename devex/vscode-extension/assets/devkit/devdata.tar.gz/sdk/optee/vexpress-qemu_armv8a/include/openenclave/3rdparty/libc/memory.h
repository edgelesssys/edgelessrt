#include <string.h>
#include <bits/deprecations.h>
