typedef uint32_t Elf_Symndx;
#include <bits/deprecations.h>
