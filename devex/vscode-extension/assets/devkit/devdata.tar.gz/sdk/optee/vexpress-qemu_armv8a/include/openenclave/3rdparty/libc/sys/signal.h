#warning redirecting incorrect #include <sys/signal.h> to <signal.h>
#include <signal.h>
#include <bits/deprecations.h>
