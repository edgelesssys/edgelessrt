ARMv8 Emulator for Open Enclave
===============================

This package contains a precompiled version of the
[Quick EMUlator (QEMU)](https://www.qemu.org/).
This version is capable of emulating an ARMv8 system with ARM TrustZone support.
Additionally, this package includes the required forks of Linux and OP-TEE to
allow for enclaves built with the Open Enclave SDK to run.

## Requirements

- Ubuntu 18.04 LTS, or later, OR;
- Windows Subsystem for Linux (WSL) with Ubuntu 18.04 LTS, or later.

## Quick Start

Install prerequisites:

```bash
sudo apt install -y screen gdb-multiarch libpixman-1-0 libfdt1
```

In the folder where the package was extracted, run:

```bash
./qemu-system-aarch64                                                               \
  -nographic                                                                        \
  -serial pty -serial pty                                                           \
  -s -S -machine virt,secure=on -cpu cortex-a57                                     \
  -d unimp -semihosting-config enable,target=native                                 \
  -m 1057                                                                           \
  -bios bl1.bin                                                                     \
  -initrd rootfs.cpio.gz                                                            \
  -kernel Image -no-acpi                                                            \
  -append 'console=ttyAMA0,38400 keep_bootcon root=/dev/vda2'                       \
  -virtfs local,id=sh0,path=$HOME,security_model=passthrough,readonly,mount_tag=sh0 \
  -netdev user,id=vmnic -device virtio-net-device,netdev=vmnic
```

The emulated CPU is now up, but execution is paused. Notice output similar to
the following:

```
char device redirected to /dev/pts/1 (label serial0)
char device redirected to /dev/pts/2 (label serial1)
```

The paths `/dev/pts/*` might differ on your system. These are virtual serial
ports connected to the emulated environment. The first one corresponds to the
serial port used by Linux, while the second corresponds to that used by OP-TEE.

Open two terminals and connect to each emulated serial port using `screen`,
replacing the PTS numbers as necessary. For example:

```bash
screen /dev/pts/1
```

Open a third terminal, navigate to where the package was extracted, and run:

```bash
gdb-multiarch
```

Once inside GDB, type:

```
target remote :1234
symbol-file ./tee.elf
b _start
g
```

These commands connect GDB to the emulator on `localhost:1234`, load the symbols
for OP-TEE, place a breakpoint on OP-TEE's entry point, and start the emulated
processor.

### Symbols

This package contains the binaries for OP-TEE (`tee.elf`) and for Linux
(`vmlinux`) that were produced during the build process, before stripping. These
may be loaded into GDB as sources for symbols.

The source code for the various components may be obtained as follows:

```bash
sudo apt install -y repo

repo init -u https://github.com/ms-iot/optee_manifest -m oe_qemu_v8.xml -b oe-3.6.0
repo sync -j$(nproc)
```

Seeing as the paths to the source files on the debugging system will not match
those on the system where the binaries were built, use GDB's path substitution
command as necessary:

```
set substitute-path from to
```

See the
[GDB documentation](https://sourceware.org/gdb/onlinedocs/gdb/Source-Path.html)
for details.

## Further Reading

For a complete guide to debugging enclaves built with Open Enclave on the
emulator, refer to
[Debugging Enclaves on OP-TEE OS with QEMU](https://github.com/openenclave/openenclave/blob/master/docs/GettingStartedDocs/OP-TEE/Debugging/QEMU.md)
on GitHub.

That guide describes how to build the emulated environment from scratch, and how
to load and debug Open Enclave enclaves once the environment is built. The
contents of this package are what result from the build steps in the guide, so
there is no need to build it again.

The guide requires that a TA Dev Kit be present to build the Open Enclave SDK.
This kit is generated when OP-TEE is built. The kit that corresponds to the
version of OP-TEE in this package is included inside it under the folder
`devkit`. As such, the parameter `-DOE_TA_DEV_KIT_DIR` as required by the Open
Enclave build step in the guide should be set to
`/path/to/extracted/package/devkit`.
