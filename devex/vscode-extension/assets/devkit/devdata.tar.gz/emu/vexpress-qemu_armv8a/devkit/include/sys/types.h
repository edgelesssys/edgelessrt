/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2014, STMicroelectronics International N.V.
 */
#ifndef SYS_TYPES_H
#define SYS_TYPES_H

#include <types_ext.h>

#endif /*SYS_TYPES_H*/
