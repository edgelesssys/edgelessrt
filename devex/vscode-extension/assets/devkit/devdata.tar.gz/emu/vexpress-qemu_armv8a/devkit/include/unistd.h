/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2014, STMicroelectronics International N.V.
 */
#ifndef UNISTD_H
#define UNISTD_H

#include <stdint.h>
#include <stddef.h>

#define __ssize_t_defined
typedef intptr_t ssize_t;

#endif
